// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
int
n_win_txtbox_nonascii_single( n_win_txtbox *p, const n_posix_char *str )
{

	// [ Mechanism ]
	//
	//	ANSI version is not applicable
	//	ANSI is safe with CJK characters
	//
	//	Unicode version needs some trick
	//	but below code is not perfect


	int ret = 0;

#ifdef UNICODE

	SIZE size;

	if ( str[ 0 ] < 256 )
	{

		n_memory_copy( &p->size_halfwidth.cx, &size, sizeof( SIZE ) );

	} else {

		if ( n_win_txtbox_is_fullwidth( str[ 0 ] ) )
		{
			n_memory_copy( &p->size_fullwidth.cx, &size, sizeof( SIZE ) );
		} else {
			n_memory_copy( &p->size_halfwidth.cx, &size, sizeof( SIZE ) );
		}

	}

	if ( size.cx > p->size_halfwidth.cx ) { ret = 1; }

#endif // #ifdef UNICODE


	return ret;
}

// internal
void
n_win_txtbox_fastmode_check
(
	      n_win_txtbox *p,
	const n_posix_char *str,
	               int *ret_cch,
	               int *ret_sx,
	      n_posix_bool *ret_tab,
	      n_posix_bool *ret_fast,
	      n_posix_bool *ret_surrogatepair
)
{

	n_posix_bool tab           = n_posix_false;
	n_posix_bool surrogatepair = n_posix_false;


	int i = 0;
	int l = 0;
	int r = 0;
	while( 1 )
	{

		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }


		if ( str[ i ] == N_STRING_CHAR_TAB )
		{
			tab = n_posix_true;
		}


		if (
			( n_string_is_ascii( str, i ) )
			||
			( n_win_txtbox_is_fullwidth( str[ i ] ) )
		)
		{
			r++;
		}


		if (
			( n_unicode_surrogatepair_is_hi( str[ i + 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( str[ i + 1 ] ) )
		)
		{
			surrogatepair = n_posix_true;
		}


		int nonascii = n_win_txtbox_nonascii_single( p, &str[ i ] );

		i++;
		l++;

		l += nonascii;

	}


	if ( ret_cch  != NULL ) { (*ret_cch  ) = i; }
	if ( ret_sx   != NULL ) { (*ret_sx   ) = l; }


	if ( ret_tab           != NULL ) { (*ret_tab          ) = tab;           }
	if ( ret_fast          != NULL ) { (*ret_fast         ) = ( i == r );    }
	if ( ret_surrogatepair != NULL ) { (*ret_surrogatepair) = surrogatepair; }


	return;
}

// internal
n_posix_char*
n_win_txtbox_tab2space
(
	      n_win_txtbox  *p, 
	const n_posix_char  *arg,
	               int   tabstop,
	               int  *ret_len,
	               int  *ret_sx,
	       n_posix_bool *ret_tab_is_exist,
	       n_posix_bool *ret_fastmode,
	       n_posix_bool *ret_surrogatepair,
	       n_posix_bool  ret_str_needed

)
{

	// [!] : this module based on n_string_tab2space()


	// [!] : you need to n_memory_free() a returned variable


	if ( arg == NULL )
	{

		if ( ret_len           != NULL ) { (*ret_len           ) =             0; }
		if ( ret_sx            != NULL ) { (*ret_sx            ) =             0; }
		if ( ret_tab_is_exist  != NULL ) { (*ret_tab_is_exist  ) = n_posix_false; }
		if ( ret_fastmode      != NULL ) { (*ret_fastmode      ) = n_posix_true ; }
		if ( ret_surrogatepair != NULL ) { (*ret_surrogatepair ) = n_posix_false; }

		return NULL;
	}


	int len_f = 0;
	int len_l = 0;

	n_posix_bool tab_is_exist = n_posix_false;
	n_win_txtbox_fastmode_check( p, arg, &len_f, &len_l, &tab_is_exist, ret_fastmode, ret_surrogatepair );

	if ( ret_tab_is_exist != NULL ) { (*ret_tab_is_exist) = tab_is_exist; }

	if ( tab_is_exist == n_posix_false )
	{
		if ( ret_len != NULL ) { (*ret_len) = len_f; }
		if ( ret_sx  != NULL ) { (*ret_sx ) = len_l; }

		if ( ret_str_needed )
		{
			return n_string_carboncopy_length( arg, len_f );
		} else {
			return NULL;
		}
	}


	// [!] : enough size

	if ( tabstop <= 0 ) { tabstop = 8; }

	int           len_t = len_f * tabstop;
	n_posix_char *s     = NULL;
	if ( ret_str_needed )
	{
		s = n_string_new_fast( len_t );
	}

	int i,ii, tab, line;

	i = ii = line = 0;
	while( 1 )
	{

		if ( arg[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( arg[ i ] == N_STRING_CHAR_TAB )
		{
//s[ii] = '_'; ii++;

			tab = tabstop - ( line % tabstop );

			while( 1 )
			{

				// [DEBUG] : use '_'

				if ( ret_str_needed )
				{
					s[ ii ] = N_STRING_CHAR_SPACE;
				}


				ii++; line++;
				if ( ii >= len_t ) { break; }

				tab--;
				if ( tab <= 0 ) { break; }
			}

		} else {

			if ( ret_str_needed )
			{
				s[ ii ] = arg[ i ];
			}

			line += n_win_txtbox_nonascii_single( p, &arg[ i ] );

			ii++; line++;
			if ( ii >= len_t ) { break; }
		}


		i++;

	}


	if ( ret_len != NULL ) { (*ret_len) = ii;   }
	if ( ret_sx  != NULL ) { (*ret_sx ) = line; }

	
	if ( ret_str_needed )
	{
		n_string_terminate( s, ii );
	}


	return s;
}

// internal
int
n_win_txtbox_nonascii( n_win_txtbox *p, const n_posix_char *str, int tabstop )
{

	int sx = 0; n_win_txtbox_tab2space( p, str, tabstop, NULL,&sx, NULL,NULL,NULL, n_posix_false );


	return sx;
}

// internal
n_posix_char*
n_win_txtbox_character
(
	      n_win_txtbox *p,
	const n_posix_char *str,
	               s32  index,
	              SIZE *ret_size,
	               s32 *ret_cch,
	               s32 *ret_tab
)
{

	// [ Mechanism ]
	//
	//	call this module from begining of a string
	//
	//	index    : element counter
	//	ret_size : pixel metrics of returned string
	//	ret_cch  : tabbed character count
	//	ret_tab  : accumulated tabbed character count


	static n_posix_char character[ 10 ];

	if ( ret_size == NULL ) { n_string_truncate( character ); }


	s32 i = 0;
	s32 v = 0;

	s32 dbcs_cch = 0;

#ifndef UNICODE
	n_posix_bool is_dbcs = n_posix_false;
#endif // #ifdef UNICODE


	if ( str[ index ] == N_STRING_CHAR_NUL )
	{

		n_string_truncate( character );

	} else
	if ( ( str[ index ] == N_STRING_CHAR_TAB )&&( ret_tab != NULL ) )
	{

		s32 tabstop = p->tabstop;
		if ( tabstop <= 0 ) { tabstop = 8; }

		const s32 tab = tabstop - ( (*ret_tab) % tabstop );

		if ( ret_size != NULL )
		{
			n_string_padding  ( character, N_STRING_CHAR_SPACE, tab );
			n_string_terminate( character, tab );
		}

		dbcs_cch = i = tab;

	} else
	if ( n_win_txtbox_is_accentmark_char( str[ index ] ) )
	{

		//

	} else {

		if ( ret_size != NULL ) { character[ i ] = str[ index + i ]; }

		v += n_win_txtbox_nonascii_single( p, &str[ index + i ] );

		if ( n_unicode_surrogatepair_is_hi( str[ index + i ] ) )
		{
			i++;
			if ( ret_size != NULL ) { character[ i ] = str[ index + i ]; }
		}


		i++;
		dbcs_cch++;


		if ( 2 == n_string_doublebyte_increment( str[ index ] ) )
		{
#ifndef UNICODE
			is_dbcs = n_posix_true;
#endif // #ifdef UNICODE

			if ( ret_size != NULL ) { character[ i ] = str[ index + i ]; }
			i++;
		}


		while( 1 )
		{//break;

			if ( n_win_txtbox_is_accentmark_char( str[ index + i ] ) )
			{
				character[ i ] = str[ index + i ]; i++;
			} else {
				break;
			}

		}


		if ( ret_size != NULL ) { character[ i ] = N_STRING_CHAR_NUL; }

	}


	if ( ret_size != NULL )
	{

		if ( p->is_font_monospace )
		{

			SIZE size;
#ifdef UNICODE
			if ( n_win_txtbox_is_fullwidth( character[ 0 ] ) )
#else  // #ifdef UNICODE
			if ( is_dbcs )
#endif // #ifdef UNICODE
			{
				size = p->size_fullwidth;
			} else {
				size = p->size_halfwidth;
			}

			size.cx *= dbcs_cch;

			if ( ret_size != NULL ) { (*ret_size) = size; }

		} else {

			GetTextExtentPoint32( p->hdc, character, i, ret_size );

		}

	}
	if ( ret_cch  != NULL ) { (*ret_cch)  = i;     }
	if ( ret_tab  != NULL ) { (*ret_tab) += i + v; }


	return character;
}

void
n_win_txtbox_character_tabbed
(
	      n_win_txtbox *p,
	const n_posix_char *str,
	s32 stop_x, s32 stop_cch, s32 stop_tab,
	s32 *ret_x, s32 *ret_cch, s32 *ret_tab
)
{

	s32   x = 0;
	s32 cch = 0;
	s32 tab = 0;
	while( 1 )
	{

		if ( str[ cch ] == N_STRING_CHAR_NUL ) { break; }

		if ( ( stop_x   != -1 )&&( x   >= stop_x   ) ) { break; }
		if ( ( stop_cch != -1 )&&( cch >= stop_cch ) ) { break; }
		if ( ( stop_tab != -1 )&&( tab >= stop_tab ) ) { break; }

		SIZE size; n_win_txtbox_character( p, str, cch, &size, NULL, &tab );

		s32 half = size.cx / 2;

		x   += half;
		if ( ( stop_x   != -1 )&&( x   >= stop_x   ) ) { break; }

		s32 step = n_string_doublebyte_increment( str[ cch ] );
		if ( ( step == 2 )&&( str[ cch + 1 ] == N_STRING_CHAR_NUL ) ) { break; }

		if (
			( n_unicode_surrogatepair_is_hi( str[ cch + 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( str[ cch + 1 ] ) )
		)
		{
			step = 2;
		}

		x   += half;
		cch += step;

	}


	if ( ret_x   != NULL ) { (*ret_x  ) =   x; }
	if ( ret_cch != NULL ) { (*ret_cch) = cch; }
	if ( ret_tab != NULL ) { (*ret_tab) = tab; }


	return;
}

// internal
inline SIZE
n_win_txtbox_size_text_fast( n_win_txtbox *p, HDC hdc, const n_posix_char *str )
{

	// [!] : don't use p->hdc : hang-up

	SIZE size;
	GetTextExtentPoint32( hdc, str, n_posix_strlen( str ), &size );


	return size;
}

// internal
SIZE
n_win_txtbox_size_text( n_win_txtbox *p, const n_posix_char *str )
{

	HDC   hdc = GetDC( p->hwnd );
	HFONT pf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

	SIZE size = n_win_txtbox_size_text_fast( p, hdc, str );

	SelectObject( hdc, pf );
	ReleaseDC( p->hwnd, hdc );


	return size;
}


