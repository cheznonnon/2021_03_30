// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_ORANGECAT_APPNAME           n_posix_literal( "OrangeCat" )
#define N_ORANGECAT_COMPUTER          n_posix_literal( "Computer" )
#define N_ORANGECAT_FIND              n_posix_literal( "Find" )
#define N_ORANGECAT_CONTROLPANEL      n_posix_literal( "Control Panel" )
#define N_ORANGECAT_CPL_EXE           n_posix_literal( "control.exe" )
#define N_ORANGECAT_SETTINGS          n_posix_literal( "Settings" )
#define N_ORANGECAT_SETTINGS_EXE      n_posix_literal( "Explorer.exe shell:AppsFolder\\Windows.ImmersiveControlPanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel" )
#define N_ORANGECAT_SHUTDOWN          n_posix_literal( "Shutdown" )
#define N_ORANGECAT_SHUTDOWN_EXE      n_posix_literal( "shutdown.exe /s /t 0" )
//#define N_ORANGECAT_SHUTDOWN_EXE      n_posix_literal( "shutdown.exe /?" ) /* Debug */
#define N_ORANGECAT_OPTION_LABEL      n_posix_literal( "-label" )
#define N_ORANGECAT_OPTION_NOLINK     n_posix_literal( "-link:off" )
#define N_ORANGECAT_OPTION_FIND_NAME  n_posix_literal( "-find:name" )
#define N_ORANGECAT_OPTION_FIND_TEXT  n_posix_literal( "-find:text" )
#define N_ORANGECAT_OPTION_AS_ITEM    n_posix_literal( "-folder_as_item" )
#define N_ORANGECAT_OPTION_SET        n_posix_literal( "-set:" )
#define N_ORANGECAT_MSG_IS_OC         n_posix_literal( "OrangeCat.IsOC" )
#define N_ORANGECAT_MSG_DRAG_INTERNAL n_posix_literal( "OrangeCat.Drag.Internal" )
#define N_ORANGECAT_MSG_DRAG_EXTERNAL n_posix_literal( "OrangeCat.Drag.External" )
#define N_ORANGECAT_MSG_DRAG_OC2OC    n_posix_literal( "OrangeCat.Drag.OC2OC" )
#define N_ORANGECAT_MSG_PATH_SX       n_posix_literal( "OrangeCat.Path.Size.X" )
#define N_ORANGECAT_MSG_PATH_SY       n_posix_literal( "OrangeCat.Path.Size.Y" )
#define N_ORANGECAT_MSG_IS_COMPUTER   n_posix_literal( "OrangeCat.IsComputer" )
#define N_ORANGECAT_MSG_HWND          n_posix_literal( "OrangeCat.HWND" )
#define N_ORANGECAT_MSG_IS_DROPPABLE  n_posix_literal( "OrangeCat.IsDroppable" )
#define N_ORANGECAT_MSG_FIND_ONOFF    n_posix_literal( "OrangeCat.Find.OnOff" )
#define N_ORANGECAT_MSG_DND_ONOFF     n_posix_literal( "OrangeCat.DnD.OnOff" )


#define N_ORANGECAT_INTERVAL_BASE     ( 100 )
#define N_ORANGECAT_INTERVAL_INIT     ( N_ORANGECAT_INTERVAL_BASE * 5 )
#define N_ORANGECAT_INTERVAL_SYNC     ( N_ORANGECAT_INTERVAL_BASE * 2 )
#define N_ORANGECAT_INTERVAL_FADE     ( N_ORANGECAT_INTERVAL_BASE * 5 )
#define N_ORANGECAT_INTERVAL_LOCK     N_BMP_FADE_MSEC
#define N_ORANGECAT_INTERVAL_DRAG     ( N_ORANGECAT_INTERVAL_BASE * 5 )
#define N_ORANGECAT_INTERVAL_PBAR     ( N_ORANGECAT_INTERVAL_BASE * 2 )


#define N_ORANGECAT_NOTHING          ( -10 ) // [!] : for debugging : avoid N_ORANGECAT_DRAG_*


#define N_ORANGECAT_VIEW_FILE         0
#define N_ORANGECAT_VIEW_INFO         1

#define N_ORANGECAT_VIEW_TYPE_LOGO    0
#define N_ORANGECAT_VIEW_TYPE_ICON    1
#define N_ORANGECAT_VIEW_TYPE_PATH    2
#define N_ORANGECAT_VIEW_TYPE_DATE    3
#define N_ORANGECAT_VIEW_TYPE_SIZE    4


#define N_ORANGECAT_VIEW_HOVER_NONE   0
#define N_ORANGECAT_VIEW_HOVER_PATH   1
#define N_ORANGECAT_VIEW_HOVER_ITEM   2
#define N_ORANGECAT_VIEW_HOVER_SCRL   3


#define N_ORANGECAT_VIEW_FOCUS_ITEM   0
#define N_ORANGECAT_VIEW_FOCUS_PATH   1


#define N_ORANGECAT_STYLE_CLASSIC     0
#define N_ORANGECAT_STYLE_LUNA        1
#define N_ORANGECAT_STYLE_AERO        2
#define N_ORANGECAT_STYLE_8           3
#define N_ORANGECAT_STYLE_AQUA        4


#define N_ORANGECAT_FIND_MODE_NONE    0
#define N_ORANGECAT_FIND_MODE_NAME    1
#define N_ORANGECAT_FIND_MODE_TEXT    2


#define N_ORANGECAT_DRAG_BREADCRUMB  -3
#define N_ORANGECAT_DRAG_SCROLL      -2
#define N_ORANGECAT_DRAG_UNKNOWN     -1
#define N_ORANGECAT_DRAG_NEUTRAL      0
#define N_ORANGECAT_DRAG_LBUTTON      1
#define N_ORANGECAT_DRAG_MBUTTON      2
#define N_ORANGECAT_DRAG_RBUTTON      3
#define N_ORANGECAT_DRAG_VBUTTON      4


#define N_ORANGECAT_LOAD_NONE         0
#define N_ORANGECAT_LOAD_INIT         1
#define N_ORANGECAT_LOAD_MAIN         2
#define N_ORANGECAT_LOAD_DONE         3


#define N_ORANGECAT_PROGRESS_NONE     0
#define N_ORANGECAT_PROGRESS_INIT     1
#define N_ORANGECAT_PROGRESS_100P     2
#define N_ORANGECAT_PROGRESS_LAST     3


#define N_ORANGECAT_STYLE_MSEC     1000


#define N_ORANGECAT_DROP_ID           2
#define N_ORANGECAT_DROP_MSEC         1


#define N_ORANGECAT_TOOLTIP_NONE      ( 0 << 0 )
#define N_ORANGECAT_TOOLTIP_TOOLTIP   ( 1 << 0 )
#define N_ORANGECAT_TOOLTIP_CAPTION   ( 1 << 1 )


#define N_ORANGECAT_CAPTURE_NEUTRAL   ( 0 )
#define N_ORANGECAT_CAPTURE_CLICKED   ( 1 )
#define N_ORANGECAT_CAPTURE_CAPTURE   ( 2 )


#define N_OC_ITEM_AUTOSCROLL_DEFAULT   ( 0 )
#define N_OC_ITEM_AUTOSCROLL_CENTERING ( 1 )
#define N_OC_ITEM_AUTOSCROLL_SMART     ( 2 )


#define N_OC_ITEM_FORCED_FRAME_NONE    ( 0 )
#define N_OC_ITEM_FORCED_FRAME_ON_1    ( 1 )
#define N_OC_ITEM_FORCED_FRAME_ON_2    ( 2 )


#define N_OC_THREAD_NAMESPACE          n_posix_literal( "OrangeCat.Thread.Sync" )


#define N_ORANGECAT_MENU_BACK           0
#define N_ORANGECAT_MENU_HOME           1
#define N_ORANGECAT_MENU_VIEW           2
#define N_ORANGECAT_MENU_VIEW_LOGO      3
#define N_ORANGECAT_MENU_VIEW_ICON      4
#define N_ORANGECAT_MENU_VIEW_PATH      5
#define N_ORANGECAT_MENU_VIEW_DATE      6
#define N_ORANGECAT_MENU_VIEW_SIZE      7
#define N_ORANGECAT_MENU_ICON           8
#define N_ORANGECAT_MENU_ICON_16        9
#define N_ORANGECAT_MENU_ICON_24       10
#define N_ORANGECAT_MENU_ICON_32       11
#define N_ORANGECAT_MENU_ICON_48       12
#define N_ORANGECAT_MENU_ICON_64       13
#define N_ORANGECAT_MENU_ICON_256      14
#define N_ORANGECAT_MENU_BPP           15
#define N_ORANGECAT_MENU_BPP_04        16
#define N_ORANGECAT_MENU_BPP_08        17
#define N_ORANGECAT_MENU_BPP_32        18
#define N_ORANGECAT_MENU_STYLE         19
#define N_ORANGECAT_MENU_STYLE_AUTO    20
#define N_ORANGECAT_MENU_STYLE_CLASSIC 21
#define N_ORANGECAT_MENU_STYLE_LUNA    22
#define N_ORANGECAT_MENU_STYLE_AERO    23
#define N_ORANGECAT_MENU_STYLE_8       24
#define N_ORANGECAT_MENU_STYLE_AQUA    25
#define N_ORANGECAT_MENU_TOOL          26
#define N_ORANGECAT_MENU_TOOL_FOLDER   27
#define N_ORANGECAT_MENU_TOOL_CMD      28
#define N_ORANGECAT_MENU_TOOL_PROPERTY 29
#define N_ORANGECAT_MENU_TOOL_EXPLORER 30
#define N_ORANGECAT_MENU_LINE          31
#define N_ORANGECAT_MENU_OUTPUT_FIND_1 32
#define N_ORANGECAT_MENU_OUTPUT_FIND_2 33




typedef struct {

	n_posix_char *main;
	n_posix_char *head;
	n_posix_char *home;
	n_posix_char *exec;
	n_posix_char *back;
	n_posix_char *find;
	n_posix_char *info;
	n_posix_char *cpnl;
	n_posix_char *link;
	n_posix_char *navi;

	UINT         msg_is_oc;
	UINT         msg_drag_internal, msg_drag_external, msg_drag_oc2oc;
	UINT         msg_path_sx, msg_path_sy;
	UINT         msg_is_computer;
	UINT         msg_hwnd;
	UINT         msg_is_droppable;
	UINT         msg_find_onoff;
	UINT         msg_dnd_onoff;

	UINT         timer_id_style;
	UINT         timer_id_drop;

	int          capture_phase;
	n_bool       is_input, is_lbutton, is_mbutton, is_rbutton;
	n_bool       input_onoff;
	n_bool       activate_onoff;
	n_bool       focuskeeper_onoff;
	n_uxtheme    uxtheme;
	n_bool       is_draggable;
	s32          cursor_x, cursor_y, cursor_px, cursor_py;
	n_bool       is_inner;
	n_bool       is_internal_dnd, is_external_dnd;
	RECT         client;
	s32          unit;
	s32          unit_path;
	s32          unit_icon;
	s32          unit_scrl;
	s32          unit_mrgn;
	s32          unit_rect;
	s32          unit__dpi;
	s32          unit_scal;
	s32          unit_rsrc;
	s32          unit__bpp;
	int          style;
	n_bool       style_auto;
	int          style_scrollbar;
	int          stripe;
	n_bool       is_round;
	n_bool       dwm_onoff;
	n_bool       font_smooth_auto;
	n_bool       font_smooth_onoff;
	n_bool       dragselection_alpha_onoff;
	n_bool       lineselection_onoff;
	int          icon_resource;
	n_bool       is_initialized;
	int          tooltip_mode;
	n_bool       tooltip_richtip_onoff;
	n_bool       exit_onoff;
	n_bool       lnk_onoff;
	n_bool       global_thread_onoff;

	int          event;
	int          find_mode;

	n_bool       navigate_plzwait;

	int          view;
	int          view_prev;
	int          view_type;
	n_bool       view_is_computer;
	n_bool       view_find_startup;

	s32          view_gallery_step;
	s32          view_gallery_size;
	s32          view_gallery_style;

	int          view_focus;
	int          view_hover;
	int          view_drag_internal;
	int          view_drag_external;
	int          view_drag_oc2oc;
	HWND         view_hwnd;
	n_bool       view_is_desktop;
	n_bool       view_is_changed;
	n_bool       view_is_key_operation;
	n_bool       view_is_key_operation_fade_out;
	n_bool       view_navigate_onoff;
	n_bool       view_dnd_onoff;

	double       view_scroll_restore;
	double       view_scroll_back;

	s32          view_icon_fxsize;
	s32          view_text_fxsize;

	n_bool       fade_onoff;
	n_bool       transition_onoff;
	n_bool       transition_is_running;
	int          transition_event;
	int          transition_type;
	n_bmp        transition_bmp_old;
	n_bmp        transition_bmp_new;
	int          transition_throbber_phase;

	n_game_click singleclick_l;
	n_game_click singleclick_m;
	n_game_click singleclick_r;
	n_game_click doubleclick_l;
	n_game_click doubleclick_m;
	n_game_click doubleclick_r;

	n_game_click singleclick_delete;
	n_game_click singleclick_bspace;

	n_win_scrollbar scrollbar;
	int             scrollbar_prv_pos;

	ITaskbarList3 *ITaskbarList3;

	n_win_titlemenu  titlemenu;
	n_win_simplemenu menu;


	// [!] : search "oc.debug_benchmark_onoff" to track
	//
	//	a : orangecat.c    : n_game_init()
	//	b : orangecat.c    : n_game_loop()
	//	c : oc_item_sync.c : n_oc_item_sync_event()

	n_bool       debug_benchmark_onoff;
	u32          debug_benchmark_timer;

	// [!] : for n_game_hwndprintf()

	n_bool       debug_use_title;

	// [!] : sync system debugging

	n_bool       debug_sync;

	// [!] : autoscroll debugging

	n_bool       debug_autoscroll_onoff;
	s32          debug_autoscroll_x;
	s32          debug_autoscroll_y;

	// [!] : drag2select debugging

	n_bool       debug_drag2select_onoff;

	// [!] : icon BPP/Size debugging

	n_bool       debug_icon;

} n_oc_main;


typedef struct {

	int         count;
	n_bmp      *bmp;
	n_vector    name;


	// internal

	n_gdi       gdi;

	n_bmp_fade *fade;
	int         focus, hover, press;

	n_bmp      *clickable_bmp;
	u32         clickable_color_fg;
	u32         clickable_color_bg;


	// cache

	n_bool     *cache_is_init;
	n_bool     *cache_onoff;
	n_bmp      *cache_bmp;
	n_bool     *cache_percent;
	int        *cache_psx;
	int        *cache_psy;
	u32        *cache_color;

} n_oc_path;


typedef struct {

	n_bool onoff;
	int    phase;
	n_bool first;
	u32    timer;

	u32    color;

	int    redraw_lct;
	double redraw_prv;
	double redraw_cur;
	s32    redraw_pos;

} n_oc_item_progressbar;


typedef struct {

	// n_oc_item_init()

	n_dir         dir;
	int           count, count_fake;
	n_bmp        *bmp;

	n_bmp_fade   *fade;
	n_bool        recyclebin;
	n_bool        find_onoff;
	int           hover;
	int           drag;

	int           patch_forced_hover;
	int          *patch_forced_focus;
	int          *patch_forced_frame;
	n_bool        patch_forced_focus_change;
	int           patch_forced_frame_phase;


	// n_oc_item_view_set()

	n_gdi         gdi;
	int           view_type;
	int           scroll_layout;

	n_bool        zebra_onoff;

	int           sync_folder;
	int          *sync_item;
	int          *sync_type;
	int           sync_index;
	int           sync_index_inner;
	u32           sync_timer;

	int          *load_item;
	int           load_index;
	int           load_count;
	u32           load_timer;


	// n_oc_item_draw()

	n_bool        is_blank;


	// n_oc_item_gdi2bitmap_make()

	s32           cell_sy_custom;


	// n_oc_item_on_resize()

	double        sx, sy;
	double        ox, oy;

	double        cell_sx,cell_sy;


	// n_oc_item_draw_single()

	n_bool        noframe;
	int           hover_prv;


	// n_oc_item_position_calculate()

	double        scroll_item_per_line;
	double        scroll_item_per_page;


	// n_oc_item_on_click()

	n_bool        margin_scroll_onoff;
	u32           margin_scroll_timer;

	n_bool        drag2select_onoff;
	s32           drag2select_fx;
	s32           drag2select_fy;
	s32           drag2select_x;
	s32           drag2select_y;
	s32           drag2select_sx;
	s32           drag2select_sy;

	s32           drag2select_px;
	s32           drag2select_py;
	s32           drag2select_psx;
	s32           drag2select_psy;

	n_bool        is_move_reserved;

	n_bool        out_of_bound_before;
	n_bool        out_of_bound_after;


	// n_oc_item_on_keydown()

	n_bool        lock;


	// oc_item_multifocus.c

	int          *multifocus;
	int          *multifocus_move;
	int          *multifocus_fade;


	// oc_item_sync.c

	n_bool        sync_progressbar_animation_onoff;


	// oc_item_hover2tooltip.c

	int           tooltip_phase;
	int           tooltip_hover;
	int           tooltip_index;
	int           tooltip_percent;
	n_bmp         tooltip_bmp;
	n_bmp_fade    tooltip_fade;
	n_thread      tooltip_thread;


	// oc_item_progressbar.c

	n_oc_item_progressbar progress_sync;
	n_oc_item_progressbar progress_copy;


} n_oc_item;




#define N_OC_INFO_TXTBOX_MAX ( 9 )




typedef struct {

	// internal

	n_posix_char *icon;
	n_posix_char *name;

	n_bmp         bmp;
	n_win_txtbox  txtbox[ N_OC_INFO_TXTBOX_MAX ];

	n_gdi         gdi;
	int           drive_usage;
	n_bool        drive_label_is_empty;

	u32           fg,bg;

	n_bool        is_computer_on_breadcrumb;

	s32           edit_x [ N_OC_INFO_TXTBOX_MAX ];
	s32           edit_y [ N_OC_INFO_TXTBOX_MAX ];
	s32           edit_sx[ N_OC_INFO_TXTBOX_MAX ];
	s32           edit_sy[ N_OC_INFO_TXTBOX_MAX ];
	n_bool        visible[ N_OC_INFO_TXTBOX_MAX ];

	n_bmp_fade    fade;
	u32           fade_timer;

	n_bool        is_theme_changed;

} n_oc_info;




static n_oc_main oc;
static n_oc_path path;
static n_oc_item item;
static n_oc_info info;




extern void n_oc_path_erase( n_oc_path* );
extern void n_oc_path_draw( n_oc_path* );
extern void n_oc_path_init( n_oc_path* );

extern void n_oc_path_cache_reset( n_oc_path* );
extern void n_oc_path_on_resize  ( n_oc_path* );
extern void n_oc_path_style_init ( n_oc_path* );

extern double n_oc_item_orangecat2scroll( n_oc_item*, double );
extern double n_oc_item_scroll2orangecat( n_oc_item*, double );

extern void n_oc_item_scroll_restore        ( n_oc_item* );
extern void n_oc_item_scroll_restore_back   ( n_oc_item* );
extern void n_oc_item_scroll_fontsize_redraw( n_oc_item* );

extern void   n_oc_item_sync_init     ( n_oc_item* );
extern void   n_oc_item_sync_exit     ( n_oc_item* );
extern void   n_oc_item_sync_reset    ( n_oc_item* );
extern n_bool n_oc_item_sync_go       ( n_oc_item* );
extern void   n_oc_item_sync_forcesync( n_oc_item* );

extern void n_oc_subclass_on_keydown( int, n_bool );

extern n_bool n_oc_item_autoscroll_is_inner( n_oc_item*, int );
extern n_bool n_oc_item_autoscroll_is_edge ( n_oc_item*, int, n_bool*, n_bool* );
extern void   n_oc_item_autoscroll         ( n_oc_item*, int, n_bool );

extern void n_oc_item_drag2select_init( n_oc_item* );
extern void n_oc_item_drag2select_loop( n_oc_item* );
extern void n_oc_item_drag2select_exit( n_oc_item* );
extern void n_oc_item_drag2select_draw( n_oc_item* );

extern void n_oc_item_multifocus_debug( const n_posix_char* );
extern void n_oc_item_multifocus_move_on( n_oc_item*, int );
extern void n_oc_item_multifocus_fade_on( n_oc_item*, int );
extern void n_oc_item_multifocus_fade_off( n_oc_item* );
extern void n_oc_item_multifocus_fade_always_on( n_oc_item*, u32 );
extern void n_oc_item_multifocus_off_all( n_oc_item* );
extern void n_oc_item_multifocus_off( n_oc_item* );
extern int  n_oc_item_multifocus_single( n_oc_item* );
extern int  n_oc_item_multifocus_count( n_oc_item* );
extern int  n_oc_item_multifocus_count_forced_frame( n_oc_item* );
extern int  n_oc_item_multifocus_forced_count( n_oc_item* );
extern void n_oc_item_multifocus_forced_sync( n_oc_item* );
extern void n_oc_item_multifocus_forced_frame( n_oc_item* );
extern void n_oc_item_multifocus_sync_image( n_oc_item* );
extern n_bool n_oc_item_multifocus_is_on( n_oc_item* );
extern n_posix_char* n_oc_item_multifocus_focus2path_new( n_oc_item* );
extern void n_oc_item_multifocus_path2focus      ( n_oc_item*, const n_posix_char*, n_bool );
extern void n_oc_item_multifocus_path2focus_light( n_oc_item*, const n_posix_char*, n_bool, n_bool );
extern void n_oc_item_multifocus_focus2path      ( n_oc_item*,       n_posix_char*       );
extern n_bool n_oc_item_multifocus_dnd( const n_posix_char*, const n_posix_char*, int, n_bool* );

extern void n_oc_item_preload_thread_go( u32 );

extern void n_oc_item_progressbar_reset( n_oc_item_progressbar*, int );
extern void n_oc_item_progressbar_main( n_oc_item_progressbar*, int, int );

extern void n_oc_item_draw_single( n_oc_item*, int, n_bool );
extern void n_oc_item_position_calculate( n_oc_item*, int, s32*, s32*, n_bool );

extern void n_oc_item_hover2tooltip_draw( n_oc_item*, n_bool );


