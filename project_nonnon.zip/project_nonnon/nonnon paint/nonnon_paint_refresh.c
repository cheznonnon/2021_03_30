// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_paint_canvas_zoom_bitmap( void )
{
//n_bmp_new( bmp, sx,sy ); return;


	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = 0;
	gdi.sy                  = 0;
	gdi.scale               = ( n_win_dpi( hwnd_main ) / 96 ) * 2;//N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = n_bmp_white_invisible;

	gdi.text                = NULL;
	gdi.text_font           = n_project_stdfont();
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = n_bmp_black;
	gdi.text_color_contour  = n_bmp_white;
	gdi.text_fxsize2        = gdi.scale;


	gdi.text_size = n_paint_desktop_sx / 50;
//n_win_hwndprintf_literal( hwnd_main, " %d ", gdi.text_size );

	gdi.text = n_posix_literal( "Zoom In" );
	n_gdi_bmp( &gdi, &n_paint_bmp_zoom_i );

	gdi.sx = gdi.sy = 0;
	gdi.text = n_posix_literal( "Zoom Out" );
	n_gdi_bmp( &gdi, &n_paint_bmp_zoom_o );


	return;
}

n_bool
n_paint_canvas_layername_bitmap( void )
{

	if ( n_paint_layer_onoff == n_false ) { return n_false; }


	if ( NULL != N_BMP_PTR( &n_paint_bmp_name ) ) { return n_false; }


	n_gdi gdi; n_gdi_zero( &gdi );


	int y = n_paint_layer_txtbox.select_cch_y;
	n_posix_char str[ 100 ];

	if ( n_string_is_empty( n_paint_layer_data[ y ].name ) )
	{
		n_posix_sprintf_literal( str, "%02d", y );
	} else {
		n_posix_sprintf_literal( str, "%02d : %s", y, n_paint_layer_data[ y ].name );
	}

	gdi.sx                  = 0;
	gdi.sy                  = 0;
	gdi.scale               = ( n_win_dpi( hwnd_main ) / 96 ) * 2;//N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = n_bmp_white_invisible;

	gdi.text                = str;
	gdi.text_font           = n_project_stdfont();
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	//gdi.text_color_main     = n_bmp_black;
	//gdi.text_color_contour  = n_bmp_white;
	gdi.text_fxsize2        = gdi.scale * 1;

	s32 msy; n_paint_margin_get( NULL, &msy );
	gdi.text_size = (double) msy / 3 * 2;
//n_win_hwndprintf_literal( hwnd_main, " %d ", gdi.text_size );


	gdi.text_color_contour = n_bmp_white;

	if ( n_paint_bmp_name_count & 1 )
	{
		gdi.text_color_main = n_bmp_rgb( 255,0,150 );
	} else {
		gdi.text_color_main = n_bmp_rgb( 0,150,255 );
	}


	n_gdi_bmp( &gdi, &n_paint_bmp_name );


	return n_true;
}

inline u32
n_paint_canvas_grabber_pixel( n_bmp *grab, s32 x, s32 y, u32 color )
{

	u32 color_grab; n_paint_grabber_pixel_get( grab, x, y, 0, &color_grab, NULL, 0.0 );


	if ( n_paint_tool_per_pixel_alpha_onoff )
	{

		int a = n_bmp_a( color_grab );

		if ( a != N_BMP_ALPHA_CHANNEL_VISIBLE )
		{
			double b = n_bmp_blend_alpha2ratio( a );
			color_grab = n_bmp_blend_pixel( color_grab, color, b );
		}

	}


	if ( n_paint_tool_blend )
	{
		color_grab = n_bmp_blend_pixel( color_grab, color, n_paint_tool_blend_ratio );
	}


	return color_grab;
}

inline u32
n_paint_canvas_grabber_alpha_pixel( s32 tx, s32 ty, u32 color )
{

	int a = n_bmp_a( color );

	if ( a == N_BMP_ALPHA_CHANNEL_VISIBLE   ) { return color; }
	if ( a == N_BMP_ALPHA_CHANNEL_INVISIBLE ) { return N_PAINT_CANVAS_COLOR; }


	u32 color_canvas = N_PAINT_CANVAS_COLOR;

	if (
//(0)&&
		( grabber )
		&&
		( n_paint_tool_per_pixel_alpha_onoff )
		&&
		( n_paint_layer_onoff == n_false )
	)
	{

		s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

		s32 gx = tx - x;
		s32 gy = ty - y;

		if ( n_bmp_ptr_is_accessible( n_paint_bmp_grab, gx,gy ) )
		{

			color_canvas = n_bmp_composite_pixel( n_paint_bmp_grab, n_paint_bmp_data, gx,gy, tx,ty, n_paint_grabber_finalize_onoff, n_paint_tool_blend_ratio );

			color_canvas = n_bmp_blend_pixel
			(
				color_canvas, N_PAINT_CANVAS_COLOR,
				n_bmp_blend_alpha2ratio( n_bmp_a( color_canvas ) )
			);

		} else {

			color_canvas = n_bmp_blend_pixel
			(
				color, color_canvas,
				n_bmp_blend_alpha2ratio( a )
			);

		}

	} else {

		color_canvas = n_bmp_blend_pixel
		(
			color, color_canvas,
			n_bmp_blend_alpha2ratio( a )
		);

	}


	return color_canvas;
}

inline u32
n_paint_highcontrast_pixel( u32 color )
{

	//static u32 cache_color = 0;
	//static u32 cache_ret   = 0;

	//if ( cache_color == color ) { return cache_ret; }

	//cache_color = color;


	if ( n_false )
	{

		int a = n_bmp_a( color );
		int r = n_bmp_r( color );
		int g = n_bmp_g( color );
		int b = n_bmp_b( color );

		r = g = b = ( r + g + b ) / 3;

		color = n_bmp_blend_pixel( ~n_bmp_alpha_invisible_pixel( color ), n_bmp_argb( a,r,g,b ), 0.8 );

	} else {

		color = n_bmp_argb2ahsl( color );

		int a = n_bmp_a( color );
		int h = n_bmp_h( color ) -  32;
		int s = n_bmp_s( color ) /   8;
		int l = n_bmp_l( color );

		color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );

	}


	//cache_ret = color;

	return color;

}

inline u32
n_paint_pixelgrid_pixel( u32 color )
{

	color = n_bmp_argb2ahsl( color );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color ) + 128;
	int s = n_bmp_s( color ) + 128;
	int l = n_bmp_l( color ) + 128;

	color = n_bmp_ahsl2argb( n_bmp_argb( a,h,s,l ) );


	return color;
}

void
n_paint_refresh_calc( void )
{

	s32 canvas_ox = 0;
	s32 canvas_oy = 0;

	n_paint_margin_get( &canvas_ox, &canvas_oy );

	s32 sx = N_BMP_SX( n_paint_bmp_data );
	s32 sy = N_BMP_SY( n_paint_bmp_data );

	n_paint_zoom_bitmap2canvas( NULL, NULL, &sx, &sy );

	sx += ( canvas_ox * 2 );
	sy += ( canvas_oy * 2 );


	s32 scrmax_x = nwin_main.rcsx - nwin_main.csx;
	s32 scrmax_y = nwin_main.rcsy - nwin_main.csy;

	if ( nwin_main.scrollx <        0 ) { nwin_main.scrollx =        0; }
	if ( nwin_main.scrolly <        0 ) { nwin_main.scrolly =        0; }
	if ( nwin_main.scrollx > scrmax_x ) { nwin_main.scrollx = scrmax_x; }
	if ( nwin_main.scrolly > scrmax_y ) { nwin_main.scrolly = scrmax_y; }


	return;
}

typedef struct {

	s32 bitmap_fx, bitmap_fy, bitmap_z, bitmap_tx, bitmap_ty;
	s32 canvas_fx, canvas_fy, canvas_z, canvas_sx, canvas_sy;

	RECT frame_outer;
	RECT frame_inner;

	n_bool z_out;

	s32 grid_center_fx, grid_center_fy;
	s32 grid_center_tx, grid_center_ty;
	s32 grid_unit;

	int id;
	int thread_count;

} n_paint_refresh_thread_struct;

void
n_paint_refresh_thread_main( n_paint_refresh_thread_struct *p )
{
//return;

	COLORREF grid_color_fg = n_paint_frame_color_fg;
	COLORREF grid_color_bg = n_paint_frame_color_bg;

	double grid_blend = 0.25;

	if ( n_paint_layer_onoff )
	{
		if ( n_paint_grabber_wholegrb_onoff )
		{
			//
		} else
		if ( n_paint_layer_txtbox.select_cch_y != n_paint_grabber_selected_index )
		{
			grid_color_fg = n_bmp_white;
			grid_color_bg = n_bmp_black + 1;
		}
	}


	s32 bitmap_start_x = p->bitmap_fx;
	s32 canvas_start_x = p->canvas_fx;


	while( 1 )
	{//break;

//if ( p->bitmap_fx <             0 ) { n_posix_debug_literal( "L" ); break; }
//if ( p->bitmap_fy <             0 ) { n_posix_debug_literal( "U" ); break; }
//if ( p->bitmap_fx >= p->bitmap_tx ) { n_posix_debug_literal( "R" ); break; }
//if ( p->bitmap_fy >= p->bitmap_ty ) { n_posix_debug_literal( "D" ); break; }


		u32 color = 0;

		if ( n_paint_layer_onoff )
		{

			color = n_bmp_layer_ptr_get( n_paint_layer_data, p->bitmap_fx, p->bitmap_fy, n_false, 0, n_true );

		} else {

			if ( NULL != N_BMP_PTR( n_paint_bmp_data ) )
			{
				if ( n_bmp_is_multithread )
				{
					n_bmp_ptr_get     ( n_paint_bmp_data, p->bitmap_fx, p->bitmap_fy, &color );
				} else {
					n_bmp_ptr_get_fast( n_paint_bmp_data, p->bitmap_fx, p->bitmap_fy, &color );
				}
			}

		}


		// [!] : n_paint_canvas_grabber_alpha_pixel() sets canvas bg color

		n_bool contour_onoff = n_false;
		u32    contour_color = color;


		if ( grabber )
		{

			POINT pt = { p->bitmap_fx, p->bitmap_fy };

			n_bool outer_onoff = PtInRect( &p->frame_outer, pt );
			n_bool inner_onoff = PtInRect( &p->frame_inner, pt );

			if ( outer_onoff )
			{
				if ( n_paint_layer_onoff )
				{
					//
				} else {
					color = contour_color = n_paint_canvas_grabber_pixel( n_paint_bmp_grab, p->bitmap_fx, p->bitmap_fy, color );
				}
			}

			color = n_paint_canvas_grabber_alpha_pixel( p->bitmap_fx, p->bitmap_fy, color );

			if (
				( outer_onoff )
				&&
				( inner_onoff == n_false )
			)
			{

				if (
					( ( p->z_out == n_false )&&( n_bmp_moire_detect( p->bitmap_fx, p->bitmap_fy, 1 ) ) )
					||
					( ( p->z_out != n_false )&&( n_bmp_moire_detect( p->canvas_fx, p->canvas_fy, 1 ) ) )
				)
				{
					color = n_bmp_blend_pixel( color, grid_color_fg, 1.0 - grid_blend );
				} else {
					color = n_bmp_blend_pixel( color, grid_color_bg,       grid_blend );
				}

			}

		} else {

			color = n_paint_canvas_grabber_alpha_pixel( p->bitmap_fx,p->bitmap_fy, color );

		}


		// [!] : checker background

		int alpha = n_bmp_a( color );

		if ( N_BMP_ALPHA_CHANNEL_VISIBLE != alpha )
		{
			u32 c = n_bmp_checker_pixel( p->bitmap_fx, p->bitmap_fy, N_BMP_SX( n_paint_bmp_data ), N_BMP_SY( n_paint_bmp_data ), N_PAINT_CANVAS_COLOR );
			color = n_bmp_blend_pixel( color, c, n_bmp_blend_alpha2ratio( alpha ) );
		}


		if ( graycanvas ) { color = n_paint_highcontrast_pixel( color ); }


		if ( pixelgrid )
		{

			u32 c = n_paint_pixelgrid_pixel( contour_color );

			contour_onoff = n_true;
			contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

		}


		if ( grid )
		{
//if ( p->grid_unit <= 0 ) { break; }

			POINT vert_pt = { p->canvas_fx, 0 };
			RECT  vert_rc = { p->grid_center_fx, 0, p->grid_center_tx + 1, 1 };

			POINT horz_pt = { p->canvas_fy, 0 };
			RECT  horz_rc = { p->grid_center_fy, 0, p->grid_center_ty + 1, 1 };

			if (
				( PtInRect( &vert_rc, vert_pt ) )
				||
				( PtInRect( &horz_rc, horz_pt ) )
			)
			{

				u32 c = n_bmp_rgb( 255,0,128 );

				contour_onoff = n_true;
				contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

			} else {

				s32 gfx = abs( p->canvas_fx - p->grid_center_fx ) % p->grid_unit;
				s32 gtx = abs( p->canvas_fx - p->grid_center_tx ) % p->grid_unit;

				n_bool gfx_is_frame = ( ( gfx == 0 )||( gfx == ( p->grid_unit - p->canvas_z ) ) );
				n_bool gtx_is_frame = ( ( gtx == 0 )||( gtx == ( p->grid_unit - p->canvas_z ) ) );

				s32 gfy = abs( p->canvas_fy - p->grid_center_fy ) % p->grid_unit;
				s32 gty = abs( p->canvas_fy - p->grid_center_ty ) % p->grid_unit;

				n_bool gfy_is_frame = ( ( gfy == 0 )||( gfy == ( p->grid_unit - p->canvas_z ) ) );
				n_bool gty_is_frame = ( ( gty == 0 )||( gty == ( p->grid_unit - p->canvas_z ) ) );

				if (
					( ( p->canvas_fx <= p->grid_center_fx )&&( gfx_is_frame ) )
					||
					( ( p->canvas_fx >= p->grid_center_tx )&&( gtx_is_frame ) )
					||
					( ( p->canvas_fy <= p->grid_center_fy )&&( gfy_is_frame ) )
					||
					( ( p->canvas_fy >= p->grid_center_ty )&&( gty_is_frame ) )
				)
				{

					u32 c = n_bmp_rgb( 0,128,255 );

					contour_onoff = n_true;
					contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

				}

			}

		}


		// [!] : n_bmp_box() : 2x slower than below loop

		//n_bmp_box( &n_paint_bmp_dbuf, p->canvas_fx, p->canvas_fy, p->canvas_z, p->canvas_z, color_new );

		s32 zoom_fx = n_posix_minmax( 0, p->canvas_sx - 1, p->canvas_fx );
		s32 zoom_fy = n_posix_minmax( 0, p->canvas_sy - 1, p->canvas_fy );
		s32 zoom_tx = n_posix_minmax( 0, p->canvas_sx - 0, p->canvas_fx + p->canvas_z );
		s32 zoom_ty = n_posix_minmax( 0, p->canvas_sy - 0, p->canvas_fy + p->canvas_z );

		s32 zoom_start_x = zoom_fx;
		s32 zoom_start_y = zoom_fy;

//if ( p->id == 0 ) { color = n_bmp_rgb(   0,200,255 ); }
//if ( p->id == 1 ) { color = n_bmp_rgb(   0,255,200 ); }
//if ( p->id == 2 ) { color = n_bmp_rgb( 255,200,  0 ); }
//if ( p->id == 3 ) { color = n_bmp_rgb( 255,  0,200 ); }

		if ( NULL != N_BMP_PTR( &n_paint_bmp_dbuf ) )
		{

			while( 1 )
			{

				u32 clr = color;

				if (
					( contour_onoff )
					&&
					(
						( zoom_fx == zoom_start_x )||( zoom_fx == ( zoom_tx - 1 ) )
						||
						( zoom_fy == zoom_start_y )||( zoom_fy == ( zoom_ty - 1 ) )
					)
				)
				{
					//if ( n_bmp_moire_detect( zoom_fx, zoom_fy, 1 ) )
					//{
						clr = contour_color;
					//} else {
						//clr = ~color;
					//}
				}


				n_bmp_ptr_set( &n_paint_bmp_dbuf, zoom_fx, zoom_fy, clr );


				zoom_fx++;
				if ( zoom_fx >= zoom_tx )
				{

					zoom_fx = zoom_start_x;

					zoom_fy++;
					if ( zoom_fy >= zoom_ty ) { break; }
				}
			}

		}


		p->bitmap_fx += p->bitmap_z;
		p->canvas_fx += p->canvas_z;

		if ( ( p->bitmap_fx >= p->bitmap_tx )||( p->canvas_fx >= p->canvas_sx ) )
		{

			p->bitmap_fx = bitmap_start_x;
			p->canvas_fx = canvas_start_x;


			p->bitmap_fy += p->bitmap_z * p->thread_count;
			p->canvas_fy += p->canvas_z * p->thread_count;

			if ( ( p->bitmap_fy >= p->bitmap_ty )||( p->canvas_fy >= p->canvas_sy ) ) { break; }
		}
	}


	return;
}

DWORD WINAPI
n_paint_refresh_thread( LPVOID lpParameter )
{

	n_paint_refresh_thread_main( (void*) lpParameter );

	return 0;
}

void
n_paint_refresh( HDC hdc, s32 fx, s32 fy, s32 tx, s32 ty, int mode, int id )
{

	// [Needed] : reduce number of accesses at startup

	if ( n_paint_refresh_lock ) { return; }

	if ( n_false == IsWindow( hwnd_main ) ) { return; }
	if ( NULL == N_BMP_PTR( n_paint_bmp_data ) ) { return; }


	if ( n_paint_pen_straight_line )
	{
		fx = 0;
		fy = 0;
		tx = N_BMP_SX( n_paint_bmp_data );
		ty = N_BMP_SY( n_paint_bmp_data );
	}


	if ( n_paint_is_shiftzoom )
	{
		fx = 0;
		fy = 0;
		tx = N_BMP_SX( n_paint_bmp_data );
		ty = N_BMP_SY( n_paint_bmp_data );
	}



	// Debug Center

	const n_bool debug_counter    = n_false;
	const n_bool debug_benchmark  = n_false;
	const n_bool background_onoff = n_true;
	const n_bool n_gdi_draw_onoff = n_true;

	u32 tick = 0;


	if ( debug_counter )
	{

		static int w = 0;
		static int c = 0;

		n_win_hwndprintf_literal( hwnd_main, "ID %d : W %d : C %d", id, w, c );

		if ( mode & N_PAINT_REFRESH_WINDOW ) { w++; }
		if ( mode & N_PAINT_REFRESH_CLIENT ) { c++; }

	}


	// Init

	const s32 bitmap_sx = N_BMP_SX( n_paint_bmp_data );
	const s32 bitmap_sy = N_BMP_SY( n_paint_bmp_data );

	const int    z       = n_paint_zoom_get( zoom );
	const n_bool z_out   = n_paint_is_zoom_out( zoom );


	// Window and Canvas

	s32 canvas_ox = 0;
	s32 canvas_oy = 0;

	n_paint_margin_get( &canvas_ox, &canvas_oy );

	static s32 canvas_sx = 0;
	static s32 canvas_sy = 0;

	if ( mode & N_PAINT_REFRESH_WINDOW )
	{

		int nwinset = N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING | N_WIN_SET_SCROLLBAR;

		s32 sx = bitmap_sx;
		s32 sy = bitmap_sy;

		n_paint_zoom_bitmap2canvas( NULL, NULL, &sx, &sy );

		sx += ( canvas_ox * 2 );
		sy += ( canvas_oy * 2 );

		n_win_set( hwnd_main, &nwin_main, sx,sy, nwinset | N_WIN_SET_CALCONLY );

		canvas_sx = nwin_main.csx;// - ( canvas_ox * 2 );
		canvas_sy = nwin_main.csy;// - ( canvas_oy * 2 );


		static s32 psx = 0;
		static s32 psy = 0;

		if (
			( ( psx != sx )||( psy != sy ) )
			||
			( ( nwin_main.rcsx != canvas_sx )||( nwin_main.rcsy != canvas_sy ) )
		)
		{

			psx = sx;
			psy = sy;


//n_bmp_new_fast( &n_paint_bmp_dbuf, canvas_sx, canvas_sy );

			s32 dbuf_sx = canvas_sx;
			s32 dbuf_sy = canvas_sy;

			n_gdi_dibsection_init( &n_paint_dibsection, &n_paint_bmp_dbuf, hwnd_main, NULL, dbuf_sx,dbuf_sy );
			n_bmp_flush( &n_paint_bmp_dbuf, N_PAINT_CANVAS_COLOR );


#ifdef _H_NONNON_WIN32_GAME_DIRECT2D
			if ( n_direct2d_is_on() )
			{
//n_win_hwndprintf_literal( hwnd_main, "Direct2D1", 0 );
				n_direct2d_make( hwnd_main, N_BMP_PTR( &n_paint_bmp_dbuf ), canvas_sx,canvas_sy );
			}
#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D

		}

	}


	//if ( mode & N_PAINT_REFRESH_SCROLL )
	{

		s32 scr_fx = nwin_main.scrollx;
		s32 scr_fy = nwin_main.scrolly;
		s32 scr_tx = nwin_main.scrollx + canvas_sx;
		s32 scr_ty = nwin_main.scrolly + canvas_sy;

		n_paint_zoom_canvas2bitmap( &scr_fx, &scr_fy, &scr_tx, &scr_ty );

		fx = n_posix_max_s32( fx, scr_fx );
		fy = n_posix_max_s32( fy, scr_fy );
		tx = n_posix_min_s32( tx, scr_tx );
		ty = n_posix_min_s32( ty, scr_ty );

		// [!] : for modulo

		tx = n_posix_min_s32( tx + 1, bitmap_sx );
		ty = n_posix_min_s32( ty + 1, bitmap_sy );

	}


	if ( z_out )
	{

		fx -= fx % z;
		fy -= fy % z;
		tx += z - ( tx % z );
		ty += z - ( ty % z );

	}


	// Grabber : always needed for n_paint_grabber_finish()

	s32 frame_size = 1;
	if ( z_out ) { frame_size = z; }

	fx = n_posix_max_s32( fx - frame_size,         0 );
	fy = n_posix_max_s32( fy - frame_size,         0 );
	tx = n_posix_min_s32( tx + frame_size, bitmap_sx );
	ty = n_posix_min_s32( ty + frame_size, bitmap_sy );


	// Clip

	if ( fx >= tx ) { return; }
	if ( fy >= ty ) { return; }

//n_win_hwndprintf_literal( hwnd_main, "%d %d %d %d", fx, fy, tx, ty );return;

	fx = n_posix_min_s32( n_posix_max_s32( 0, fx ), bitmap_sx );
	fy = n_posix_min_s32( n_posix_max_s32( 0, fy ), bitmap_sy );
	tx = n_posix_min_s32( n_posix_max_s32( 0, tx ), bitmap_sx );
	ty = n_posix_min_s32( n_posix_max_s32( 0, ty ), bitmap_sy );

//n_win_hwndprintf_literal( hwnd_main, "%d %d %d %d", fx, fy, tx, ty );return;


	{ // Redraw


	if ( debug_benchmark ) { tick = n_posix_tickcount(); }


	// Zoom


	int bitmap_z = 1;
	int canvas_z = z;

	if ( z_out )
	{
		bitmap_z = z;
		canvas_z = 1;
	}


	s32 bitmap_fx = fx;
	s32 bitmap_fy = fy;
	s32 bitmap_tx = tx;
	s32 bitmap_ty = ty;
	s32 canvas_fx = fx;
	s32 canvas_fy = fy;

	n_paint_zoom_bitmap2canvas( &canvas_fx, &canvas_fy, NULL, NULL );

	canvas_fx -= nwin_main.scrollx;
	canvas_fy -= nwin_main.scrolly;

	canvas_fx += canvas_ox;
	canvas_fy += canvas_oy;


	// [!] : this position is important

	s32 redraw_x  = canvas_fx;
	s32 redraw_y  = canvas_fy;
	s32 redraw_sx = ( tx - fx ) * canvas_z;
	s32 redraw_sy = ( ty - fy ) * canvas_z;

	redraw_x  -= canvas_ox;
	redraw_y  -= canvas_oy;
	redraw_sx += canvas_ox * 2;
	redraw_sy += canvas_oy * 2;

	if ( redraw_x < 0 ) { redraw_sx += redraw_x; redraw_x = 0; }
	if ( redraw_y < 0 ) { redraw_sy += redraw_y; redraw_y = 0; }

//n_bmp_box( &n_paint_bmp_dbuf, redraw_x, redraw_y, redraw_sx, redraw_sy, n_bmp_black );
//redraw_x = redraw_y = 0;
//redraw_sx = canvas_sx;
//redraw_sy = canvas_sy;


	// Grid

	s32 grid_center_fx = 0;
	s32 grid_center_fy = 0;
	s32 grid_center_tx = 0;
	s32 grid_center_ty = 0;
	s32 grid_unit      = 0;

	if ( grid )
	{

		// Center Line

		grid_center_fx = grid_center_tx = ( bitmap_sx / 2 );
		grid_center_fy = grid_center_ty = ( bitmap_sy / 2 );

		grid_center_fx -= ( 0 == ( bitmap_sx % 2 ) );
		grid_center_fy -= ( 0 == ( bitmap_sy % 2 ) );

		n_paint_zoom_bitmap2canvas( &grid_center_fx, &grid_center_fy, &grid_center_tx, &grid_center_ty );

		grid_center_fx -= nwin_main.scrollx;
		grid_center_fy -= nwin_main.scrolly;
		grid_center_tx -= nwin_main.scrollx;
		grid_center_ty -= nwin_main.scrolly;

		grid_center_fx += canvas_ox;
		grid_center_fy += canvas_oy;
		grid_center_tx += canvas_ox;
		grid_center_ty += canvas_oy;


		// Guide Line

		const s32 unit     = n_posix_min_s32( bitmap_sx, bitmap_sy );
		const s32 unit_min = 16;

		grid_unit = n_posix_max_s32( unit_min, unit / unit_min );
		n_paint_zoom_bitmap2canvas( &grid_unit, NULL, NULL, NULL );
		grid_unit = n_posix_max_s32( 1, grid_unit );

//n_win_hwndprintf_literal( hwnd_main, "%d", grid_unit );
	}


	// Grabber Frame : Bitmap-based : Thick Frame

	RECT frame_outer = { 0,0,0,0 };
	RECT frame_inner = { 0,0,0,0 };

	if ( grabber )
	{

		s32 frame_fx, frame_fy, frame_tx, frame_ty;
		n_paint_grabber_system_get( &frame_fx, &frame_fy, &frame_tx, &frame_ty, NULL,NULL );

		frame_tx += frame_fx;
		frame_ty += frame_fy;

		frame_fx = n_posix_max_s32(         0 - frame_size, frame_fx - frame_size );
		frame_fy = n_posix_max_s32(         0 - frame_size, frame_fy - frame_size );
		frame_tx = n_posix_min_s32( bitmap_sx + frame_size, frame_tx + frame_size );
		frame_ty = n_posix_min_s32( bitmap_sy + frame_size, frame_ty + frame_size );

		frame_outer = frame_inner = n_win_rect_set_simple( NULL, frame_fx, frame_fy, frame_tx, frame_ty );

		n_win_rect_resize( &frame_inner, -frame_size, -frame_size );

	}


	// Combined Scale Copy


	n_paint_hmutex = n_win_mutex_init( n_paint_hmutex, N_PAINT_MUTEX_REFRESH );
	if ( n_paint_hmutex == NULL ) { return; }


	// [x] : Win9x : can run but not working

	if (
//(0)&&
		//( mode & N_PAINT_REFRESH_CLIENT )
		//&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
		//&&
		//( ( canvas_fy * canvas_sy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{
//n_win_hwndprintf_literal( hwnd_main, " Multi-thread On " );


		n_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_true;


		int cores = n_thread_core_count;


		n_thread                      *h = n_memory_new( cores * sizeof( n_thread                      ) );
		n_paint_refresh_thread_struct *p = n_memory_new( cores * sizeof( n_paint_refresh_thread_struct ) );


		size_t i = 0;
		while( 1 )
		{

			n_paint_refresh_thread_struct tmp =
			{
				bitmap_fx, bitmap_fy + ( bitmap_z * i ), bitmap_z, bitmap_tx, bitmap_ty,
				canvas_fx, canvas_fy + ( canvas_z * i ), canvas_z, canvas_sx, canvas_sy,
				frame_outer, frame_inner,
				z_out,
				grid_center_fx, grid_center_fy, grid_center_tx, grid_center_ty, grid_unit,
				i,
				cores
			};

			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_refresh_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_refresh_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {
//n_win_hwndprintf_literal( hwnd_main, " Multi-thread Off " );

		n_paint_refresh_thread_struct p =
		{
			bitmap_fx,bitmap_fy,bitmap_z,bitmap_tx,bitmap_ty,
			canvas_fx,canvas_fy,canvas_z,canvas_sx,canvas_sy,
			frame_outer,frame_inner,
			z_out,
			grid_center_fx,grid_center_fy,
			grid_center_tx,grid_center_ty,
			grid_unit,
			0,1
		};

		n_paint_refresh_thread_main( &p );

	}


	if ( background_onoff )
	{

		n_bmp_box( &n_paint_bmp_dbuf, 0,                    0, canvas_sx, canvas_oy, N_PAINT_CANVAS_COLOR );
		n_bmp_box( &n_paint_bmp_dbuf, 0,canvas_sy - canvas_oy, canvas_sx, canvas_oy, N_PAINT_CANVAS_COLOR );
		n_bmp_box( &n_paint_bmp_dbuf, 0,                    0, canvas_ox, canvas_sy, N_PAINT_CANVAS_COLOR );
		n_bmp_box( &n_paint_bmp_dbuf, canvas_sx - canvas_ox,0, canvas_ox, canvas_sy, N_PAINT_CANVAS_COLOR );

		if ( grid )
		{

			COLORREF fg = n_paint_frame_color_fg;
			COLORREF bg = n_paint_frame_color_bg;

			s32 m  = canvas_ox;
			s32 x  = 0;
			s32 y  = 0;
			s32 sx = bitmap_sx;
			s32 sy = bitmap_sy;

			n_paint_zoom_bitmap2canvas( &x, &y, &sx, &sy );

			x = -nwin_main.scrollx + m;
			y = -nwin_main.scrolly + m;


			// [!] : WinVista or later : this logic is heavy because lack of 2D acceleration

			//RECT r; GetClientRect( hwnd_main, &r );
			//n_draw_gdi_frame2canvas( hdc, x,y,sx,sy, r, fg, bg );


			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y - 1, x + sx, y - 1, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y - 1, x + sx, y - 1, bg, 2 );

			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y + sy, x + sx, y + sy, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y + sy, x + sx, y + sy, bg, 2 );

			n_bmp_line_dot( &n_paint_bmp_dbuf, x - 1, y, x - 1, y + sy, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x - 1, y, x - 1, y + sy, bg, 2 );

			n_bmp_line_dot( &n_paint_bmp_dbuf, x + sx, y, x + sx, y + sy, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x + sx, y, x + sx, y + sy, bg, 2 );

		}

	}


	// Window #2 : for smooth zooming

	if ( mode & N_PAINT_REFRESH_WINDOW )
	{

		int nwinset = N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING | N_WIN_SET_SCROLLBAR;

		s32 sx = bitmap_sx;
		s32 sy = bitmap_sy;

		n_paint_zoom_bitmap2canvas( NULL, NULL, &sx, &sy );

		sx += ( canvas_ox * 2 );
		sy += ( canvas_oy * 2 );

		n_win_set( hwnd_main, &nwin_main, sx,sy, nwinset );
		n_paint_prev_scrollx = n_paint_prev_scrolly = 0;

		n_win_scrollbar_window( &n_paint_hscr, &n_paint_vscr, &nwin_main, N_PAINT_CANVAS_COLOR );

	}


	// Scrollbars

	//if ( mode & N_PAINT_REFRESH_SCROLL )
	{

		n_win_scrollbar_client( &n_paint_hscr, &n_paint_vscr, &nwin_main, N_PAINT_CANVAS_COLOR );

		// [Needed] : Classic Style

		n_bmp_free( &n_paint_hscr.bmp_th );
		n_bmp_free( &n_paint_vscr.bmp_th );

		n_win_scrollbar_draw_always( &n_paint_hscr, n_true );
		n_win_scrollbar_draw_always( &n_paint_vscr, n_true );

	}


	// Pen : straight line

	if ( ( z_out == n_false )&&( n_paint_pen_straight_line ) )
	{

		s32 c_fx = n_paint_pen_start_x;
		s32 c_fy = n_paint_pen_start_y;
		s32 c_tx = 0;
		s32 c_ty = 0;

		n_paint_zoom_bitmap2canvas( &c_fx, &c_fy, NULL, NULL );
		n_win_cursor_position_relative( hwnd_main, &c_tx, &c_ty );

		s32 canvas_ox = 0;
		s32 canvas_oy = 0;
		n_paint_margin_get( &canvas_ox, &canvas_oy );

		c_fx += canvas_ox;
		c_fy += canvas_oy;

		c_fx -= nwin_main.scrollx;
		c_fy -= nwin_main.scrolly;

		s32 circle = n_posix_max( 8, z * pensize );

		n_draw_line( &n_paint_bmp_dbuf, c_fx,c_fy, c_tx,c_ty, n_paint_pen_color, circle, z * pensize );

	}


	// Hamburger Button

	{

		u32 color_base = n_bmp_alpha_visible_pixel( N_PAINT_CANVAS_COLOR );

		s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

		if (
			(
				(
					( tooltype == N_PAINT_TOOL_TYPE_PEN )
					&&
					( n_paint_pen_start == n_false )
				)
				||
				( tooltype == N_PAINT_TOOL_TYPE_FILL )
				||
				(
					( tooltype == N_PAINT_TOOL_TYPE_GRAB )
					&&
					(
						( N_PAINT_GRABBER_IS_NEUTRAL() )
						||
						( N_PAINT_GRABBER_IS_DRAG_OK() )
					)
				)
			)
			&&
			( n_win_is_hovered_offset( hwnd_main, x,y,sx,sy ) )
		)
		{
			u32 fg = n_bmp_blend_pixel( n_bmp_white, color_base, 0.75 );
			//n_bmp_roundrect_ratio( &n_paint_bmp_dbuf, x,y,sx,sy, fg, 50 );
			n_bmp_box( &n_paint_bmp_dbuf, x,y,sx,sy, fg );
		}

		u32 bg = n_bmp_blend_pixel( n_bmp_black, color_base, 0.75 );

		double scale = (double) n_win_dpi( hwnd_main ) / 96.0;

		s32 line_sx  = sx / 3 * 2;
		s32 line_sy  = (double) 2 * scale;
		s32 line_gap = (double) 3 * scale;
		s32 line_x   = ( sx -     line_sx                            ) / 2;
		s32 line_y   = ( sy - ( ( line_sy * 3 ) + ( line_gap * 2 ) ) ) / 2;

		line_y += line_sy;

		n_bmp_box( &n_paint_bmp_dbuf, x+line_x,line_y,line_sx,line_sy, bg );
		line_y += line_sy + line_gap;

		n_bmp_box( &n_paint_bmp_dbuf, x+line_x,line_y,line_sx,line_sy, bg );
		line_y += line_sy + line_gap;

		n_bmp_box( &n_paint_bmp_dbuf, x+line_x,line_y,line_sx,line_sy, bg );
		line_y += line_sy + line_gap;

	}


	// Shift Zoom

//n_win_hwndprintf_literal( hwnd_main, " %d %d %d %d ", fx,fy,tx,ty );
//n_win_hwndprintf_literal( hwnd_main, " %d %d %d %d ", redraw_x,redraw_y,redraw_sx,redraw_sy );

	if ( n_paint_is_shiftzoom )
	{
//u32 tick = n_posix_tickcount();

//n_bmp_flush( &n_paint_bmp_dbuf, n_bmp_rgb( 0,200,255 ) );


		n_bmp_flush_mixer( &n_paint_bmp_dbuf, n_bmp_black, 0.5 );


		s32 tsx = N_BMP_SX( &n_paint_bmp_dbuf );
		s32 tsy = N_BMP_SY( &n_paint_bmp_dbuf ) / 2;

		{
			s32 fsx = N_BMP_SX( &n_paint_bmp_zoom_i );
			s32 fsy = N_BMP_SY( &n_paint_bmp_zoom_i );

			s32 x = ( tsx - fsx ) / 2;
			s32 y = ( tsy - fsy ) / 2;

			n_bmp_transcopy( &n_paint_bmp_zoom_i, &n_paint_bmp_dbuf, 0,0,fsx,fsy, x,y );
		}

		n_bmp_line( &n_paint_bmp_dbuf, 0,tsy+0,tsx,tsy+0, n_bmp_white );
		n_bmp_line( &n_paint_bmp_dbuf, 0,tsy+1,tsx,tsy+1, n_bmp_black );

		{
			s32 fsx = N_BMP_SX( &n_paint_bmp_zoom_o );
			s32 fsy = N_BMP_SY( &n_paint_bmp_zoom_o );

			s32 x = ( tsx - fsx ) / 2;
			s32 y = ( tsy - fsy ) / 2;

			n_bmp_transcopy( &n_paint_bmp_zoom_o, &n_paint_bmp_dbuf, 0,0,fsx,fsy, x,y+tsy );
		}

//n_bmp_save_literal( &n_paint_bmp_dbuf, "dbuf.bmp" );


//n_win_hwndprintf_literal( hwnd_main, " %d ", n_posix_tickcount() - tick );

//static int i = 0; n_win_hwndprintf_literal( hwnd_main, " %d ", i ); i++;
	}


	// Layer Name

	if ( n_paint_layer_onoff )
	{

		n_bool name_redraw = n_paint_canvas_layername_bitmap();

		s32 canvas_ox, canvas_oy; n_paint_margin_get( &canvas_ox, &canvas_oy );

		s32 sx = N_BMP_SX( &n_paint_bmp_name );
		s32 sy = N_BMP_SY( &n_paint_bmp_name );
//n_win_hwndprintf_literal( hwnd_main, " %d %d ", canvas_sx - ( canvas_ox * 2 ) , sx );

		if ( ( canvas_sx - ( canvas_ox * 2 ) ) >= sx )
		{
			s32 x = ( canvas_sx - sx ) / 2;
			s32 y = ( canvas_oy - sy ) / 2;

			n_bmp_transcopy( &n_paint_bmp_name, &n_paint_bmp_dbuf, 0,0,sx,sy, x,y );

			// [!] : pen input uses redraw_*

//n_win_hwndprintf_literal( hwnd_main, " %d %d %d %d ", redraw_x, redraw_y, redraw_sx, redraw_sy );
			if ( name_redraw )
			{
				redraw_x  = 0;
				redraw_y  = 0;
				redraw_sx = canvas_sx;//N_BMP_SX( &n_paint_bmp_dbuf );
				redraw_sy = n_posix_max( redraw_sy, canvas_oy );//N_BMP_SY( &n_paint_bmp_dbuf );
			}
//n_bmp_save_literal( &n_paint_bmp_dbuf, "ret.bmp" );
		}

	}


	// Draw
//n_gdi_bitmap_draw( hwnd_main, &n_paint_bmp_dbuf, 0, 0, canvas_sx, canvas_sy, 0, 0 );


	s32 offset_x = 0;

	if ( n_paint_vscr.show_onoff )
	{
		if ( n_win_is_lefthanded() )
		{
			offset_x = n_win_scrollbar_stdsize( &n_paint_vscr );
		}
	}


#ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_direct2d_is_on() )
	{
//n_win_hwndprintf_literal( hwnd_main, "n_direct2d_is_on()" );

		n_direct2d_copy( hwnd_main, N_BMP_PTR( &n_paint_bmp_dbuf ),canvas_sx,canvas_sy, 0,0 );
		n_direct2d_draw( hwnd_main, 0,0, canvas_sx,canvas_sy );

	} else

#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_gdi_draw_onoff )
	{
//n_win_hwndprintf_literal( hwnd_main, "n_gdi_draw_onoff" );

		n_gdi_bitmap_draw_main
		(
			hwnd_main, hdc, &n_paint_bmp_dbuf,
			           redraw_x, redraw_y, redraw_sx, redraw_sy,
			offset_x + redraw_x, redraw_y
		);

	}


	if ( debug_benchmark ) { n_win_hwndprintf_literal( hwnd_main, "%d", (int) n_posix_tickcount() - tick ); }


	} // Redraw


	n_paint_hmutex = n_win_mutex_exit( n_paint_hmutex );


	return;
}

