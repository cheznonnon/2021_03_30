


//#define UNICODE




#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/win_txtbox.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_txtbox txtbox;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int style_option = 0;

			//style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS;

			n_win_txtbox_init( &txtbox, hwnd, style, style_option );
		}

		{
			int i = 0;
			while ( 1 )
			{
				n_posix_char str[ 100 ];
				n_posix_sprintf_literal( str, "%d", i );
				n_win_txtbox_line_set( &txtbox, i, str );

				i++;
				if ( i >= 1000 ) { break; }
			}

		}

		MoveWindow( txtbox.hwnd, 0,0,256,256, n_true );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &txtbox );
		if ( ret ) { return ret; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

