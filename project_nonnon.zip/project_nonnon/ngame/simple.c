// NonnonGame
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html

// Partial File




void
n_ngame_simple_shuffle( n_ngame *p, int i )
{

	s32 rnd_x = n_game_random( n_posix_max_s32( 0, p->csx - p->unit ) );
	s32 rnd_y = n_game_random( n_posix_max_s32( 0, p->csy - p->unit ) );

	n_game_chara_prv( &p->obj[ i ] );
	n_game_chara_pos( &p->obj[ i ], rnd_x, rnd_y );


	return;
}

void
n_ngame_simple_shuffle_all( n_ngame *p )
{

	int i = 0;
	while( 1 )
	{

		n_ngame_simple_shuffle( p, i );

		i++;
		if ( i >= N_NGAME_OBJ_UNIT ) { break; }
	}


	return;
}

void
n_ngame_simple_srcx_init( n_ngame *p )
{

	int i = 0;
	while( 1 )
	{

		int srcx = p->unit * i;

		p->obj[ N_NGAME_OBJ_ELEM_0 + i ].srcx = srcx;

		i++;
		if ( i >= N_NGAME_OBJ_UNIT ) { break; }
	}

	return;
}

void
n_ngame_simple_collision( n_ngame *p )
{

	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_0, &N_NGAME_OBJ_BLOCK_0 );

	return;
}

void
n_ngame_simple_draw( n_ngame *p )
{

	// [!] : reverse overlay order

	n_game_chara_draw( &N_NGAME_OBJ_PANEL_0 );
	n_game_chara_draw( &N_NGAME_OBJ_BLOCK_0 );
	n_game_chara_draw( &N_NGAME_OBJ_CHARA_0 );


	n_game_refresh_on();
	return;
}

void
n_ngame_simple_edgelooping( n_ngame *p )
{

	int i = 0;
	while( 1 )
	{

		n_game_chara *c = &p->obj[ i ];

		if ( c->x < -c->sx ) { c->x = p->csx; }
		if ( c->x > p->csx ) { c->x = -c->sx; }

		if ( c->y < -c->sy ) { c->y = p->csy; }
		if ( c->y > p->csy ) { c->y = -c->sy; }

		i++;
		if ( i >= N_NGAME_OBJ_UNIT ) { break; }
	}


	{
		n_game_chara *f = &N_NGAME_OBJ_CHARA_0;
		n_game_chara *t = &N_NGAME_OBJ_BLOCK_0;

		if ( n_game_chara_is_hit_offset( f, t, p->o,p->o, 0,0 ) )
		{
			if ( f->y == p->csy ) { t->y = p->csy - t->sy; }
			if ( f->y == -f->sy ) { t->y = -f->sy + t->sy; }
			if ( f->x == p->csx ) { t->x = p->csx - t->sx; }
			if ( f->x == -f->sx ) { t->x = -f->sx + t->sx; }
		}
	}


	return;
}


